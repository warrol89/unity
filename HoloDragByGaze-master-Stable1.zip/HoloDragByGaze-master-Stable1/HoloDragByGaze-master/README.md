# HoloDragByGaze
Repo to accompany a blog about moving objects gaze and tapping them in place with a HoloLens
